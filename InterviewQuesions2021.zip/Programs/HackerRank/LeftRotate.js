function leftRotate(arr, rotations) {
  const rotatedArray = [...arr];

  for (let i = 0; i < rotations; i++) {
    const frontItem = rotatedArray.shift();
    rotatedArray.push(frontItem);
    console.log('FrontItem :' + frontItem + 'Array :' + rotatedArray);
  }

  return rotatedArray;
}

const numOfRotations = 4;
const array = [1, 2, 3, 4, 5];

console.log(leftRotate(array, numOfRotations));
