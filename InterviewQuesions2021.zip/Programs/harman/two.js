const obj = {
  value: 1,
  children: [
    {
      value: 10,
      children: [
        { value: 2 },
        { value: 9, children: [{ value: 1, children: [{ value: 1 }] }] },
      ],
    },
    { value: 5 },
  ],
};

function addition(obj) {
  let sum = 0;

  for (let item in obj) {
    if (Array.isArray(obj[item])) {
      obj[item].forEach((el) => {
        return addition(obj[el]);
      });
    } else {
      sum += obj[item];
    }
  }
  return sum;
}

console.log(Object.entries(obj));
