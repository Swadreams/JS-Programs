function sum1(a) {
  return function (b) {
    return function (c) {
      return a + b + c;
    };
  };
}

const sumtype1 = sum1(1)(2)(3);
console.log(sumtype1);

function sum2(a) {
  return function (b) {
    if (b) {
      return sum2(a + b);
    }
    return a;
  };
}

const sumtype2 = sum2(1)(2)(3)(4)();
console.log(sumtype2);

function sum3(a, b) {
  return function (c, d) {
    return a + b + c + d;
  };
}

const sumtype3 = sum3(1, 2)(3, 4);
console.log(sumtype3);

function sum4(...args) {
  const a = args.reduce((a, b) => a + b, 0);
  return function (...args) {
    const b = args.reduce((a, b) => a + b, 0);
    if (b) {
      return sum4(a + b);
    }
    return a; 
  };
}

const sumtype4 = sum4(1, 2)(3, 4)(5, 6)();
console.log(sumtype4);
const sumtype5 = sum4(1, 2, 3)(4, 5, 6)();
console.log(sumtype5);
