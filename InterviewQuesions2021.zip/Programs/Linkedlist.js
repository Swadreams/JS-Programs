function Node(value, next) {
  this.value = value;
  this.next = next;
}

function Head(next) {
  this.next = next;
}

function SinglyLinkedList() {
  this.head = new Head(null);
  this.toString = () => JSON.stringify(this);
  this.push = (value) => {
    if (!this.head.next) {
      this.head.next = new Node(value, null);
    } else {
      let currentNode = this.head.next;
      currentNode.next = new Node(value, null);
    }
  };
}

const myList = new SinglyLinkedList();

console.log(myList.toString());
myList.push(0);
myList.push(1);
myList.push(2);
console.log(myList.toString());
