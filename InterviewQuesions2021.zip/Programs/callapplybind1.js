let name = {
  firstName: 'swap',
  lastName: 'nil',
};

function printFullName(city, state) {
  console.log(
    this.firstName + ' ' + this.lastName + ' from ' + city + ' , ' + state
  );
}

let name2 = {
  firstName: 'abc',
  lastName: 'cde',
};

printFullName.call(name2, 'CA', 'Ame');
printFullName.apply(name2, ['MA', 'DURBA']);

const printName = printFullName.bind(name2, 'AA', 'AME');
printName();
