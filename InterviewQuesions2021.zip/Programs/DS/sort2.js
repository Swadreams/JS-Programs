// [4,3,2,1] => Arrange in ascending order
// Access first element to get minimum number

// Step1: Check if  first element is greater than second
// if 4 > 3  => yes => swap
// [3,4,1,5]
// now still compare 0 element with next i.e 2nd element
// 3 > 1 => yes => swap
// [1,4,3,5]
// Follow same steps Repeat steps

function sortByArray(arr) {
  if (!arr.length) {
    throw Error('Array should not be blank');
  } else if (arr.length === 1) {
    return arr[0];
  } else {
    for (let i = 0; i < arr.length; i++) {
      let outerElement = arr[i];
      for (let j = i + 1; j < arr.length; j++) {
        let innerElement = arr[j];
        if (outerElement > innerElement) {
          arr[i] = innerElement;
          arr[j] = outerElement;
          innerElement = arr[j];
          outerElement = arr[i];
        }
      }
    }
  }
  return arr[0];
}

const result = sortByArray([4, 3, 5, 2, 1]);

console.log(result);
