// [4, 1, 2, 3, 5] => min number

// Approach 1 : [1,2,3,4] => array[0]

// Step1 : First element should be treated as minimum number
// Step2 : Check if next number is min 3 < 4
// Step3 : Pretend that minimum number is 3
// Step4 : Repeate step 2 and 3 till end of array

function findMinimumNumber(arr) {
  if (!arr.length) {
    throw Error('array should not empty');
  } else if (arr.length === 1) {
    return arr[0];
  } else {
    let min = arr[0];
    for (let i = 1; i < arr.length; i++) {
      if (min > arr[i]) {
        min = arr[i];
      }
    }
    return min;
  }
}

const result = findMinimumNumber([]);
console.log(result);
