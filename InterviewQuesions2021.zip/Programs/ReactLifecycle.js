import React from 'react';

class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = { favoriteColor: 'red' };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ favoriteColor: 'blue' });
    }, 1000);
  }

  changeColor = () => {
    this.setState({ favoriteColor: 'green' });
  };

  getSnapshotBeforeUpdate(prevProps, prevState) {
    document.getElementById('div1').innerHTML =
      'Before the udpate, the favorite was ' + prevState.favoriteColor;
  }

  componentDidUpdate() {
    document.getElementById('div2').innerHTML =
      ' The udpated favorite is ' + this.state.favoriteColor;
  }

  render() {
    return (
      <div>
        <h1>My favorite color is : {this.state.favoriteColor}</h1>
        <div id='div1'></div>
        <div id='div2'></div>
        <button onClick={this.changeColor}>Click Here</button>
      </div>
    );
  }
}

export default Header;
