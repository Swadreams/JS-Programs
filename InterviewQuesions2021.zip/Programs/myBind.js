Function.prototype.mybind = function (...args) {
  let obj = this;
  const params = args.slice(1);
  return function (...args2) {
    obj.apply(args[0], [...params, ...args2]);
  };
};

let name = {
  fname: 'abc',
  lname: 'cde',
};

let printName = function (state, country) {
  console.log(this.fname + ' ' + this.lname + ' from ' + state + ' ' + country);
};

let printname1 = printName.mybind(name, 'MH', 'IND');
printname1('IND');
