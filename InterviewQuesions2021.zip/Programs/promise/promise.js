const promiseOne = () =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('Promise one resolved');
      //   reject('Promise one rejected');
    }, 500);
  });
const promiseTwo = () =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      //   resolve('Promise two resolved');
      reject('Promise two rejected');
    }, 600);
  });
const promiseThree = () =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('Promise three resolved');
      //reject('Promise three rejected');
    }, 700);
  });

const throwErrorPromise = () => {
  return new Promise((resolve, reject) => {
    reject('Took too dang long');
  }, 500);
};

const fetchData = async () => {
  try {
    const beforeTime = new Date();
    // const responseOne = await promiseOne();
    // const responseTwo = await promiseTwo();
    // const responseThree = await promiseThree();

    // const response = await Promise.race([
    //   promiseOne(),
    //   promiseTwo(),
    //   promiseThree(),
    // ]);
    const response = await Promise.allSettled([
      promiseOne(),
      promiseTwo(),
      promiseThree(),
    ]);
    // const response = await Promise.race([promiseThree(), throwErrorPromise()]);

    const afterTime = new Date();

    console.log(
      'Response from promise.all :',
      response,
      afterTime - beforeTime
    );

    // console.log(
    //   responseOne,
    //   responseTwo,
    //   responseThree,
    //   afterTime - beforeTime
    // );
  } catch (error) {
    console.log('error :', error);
  }
};

fetchData();
