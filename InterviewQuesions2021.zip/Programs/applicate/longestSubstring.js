const lns = (str) => {
  let currentSubstring = '';
  let longestSubstring = '';
  for (const i of str) {
    if (currentSubstring.includes(i)) {
      currentSubstring = currentSubstring.slice(
        currentSubstring.indexOf(i) + 1
      );
    }
    currentSubstring += i;
    if (currentSubstring.length > longestSubstring.length) {
      longestSubstring = currentSubstring;
    }
  }
  return longestSubstring;
};
