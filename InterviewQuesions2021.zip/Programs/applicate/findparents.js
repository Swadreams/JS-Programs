const arr = [
  {
    name: 'x',
    parent: 'y',
  },
  {
    name: 'y',
    parent: 'z',
  },
  {
    name: 'z',
    parent: 'a',
  },
];

function findParents(str) {
  let parents = [];

  for (let i = 0; i < arr.length; i++) {
    if (arr[i].name === str) {
      parents = [...parents, arr[i].parent];
      console.log(parents);
      findParents(arr[i].parent);
      break;
    }
  }
  return parents.join();
}

console.log(findParents('y'));
