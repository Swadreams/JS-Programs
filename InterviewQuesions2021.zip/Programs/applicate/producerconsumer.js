var data = [];

function Consumer() {
  this.isConsuming = false;

  this.notify = function () {
    if (this.isConsuming) {
      return;
    }
    this.consumeNext();
  };

  this.consumeNext = async function () {
    this.isConsuming = true;
    if (data.length > 0) {
      console.log(await this.consume(data.shift()));
      this.consumeNext();
    } else {
      this.isConsuming = false;
    }
  };

  this.consume = async function (datam) {
    return datam * datam;
  };
}

var consumer = new Consumer();
data.push(1, 2, 3, 4, 5);
consumer.notify();
