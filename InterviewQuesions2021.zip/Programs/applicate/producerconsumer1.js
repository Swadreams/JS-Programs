let dataArray = [];
let consumerResolver = null;

function producer() {
  setInterval(() => {
    const newData = 'my new Data';
    dataArray.push(newData);

    if (consumerResolver) {
      consumerResolver();
    }
  }, 1000);
}

async function consumer() {
  while (true) {
    if (dataArray.length === 0) {
      const producerPromise = new Promise((resolve) => {
        consumerResolver = resolve;
      });
      await producerPromise;
    }

    consumerResolver = null;
    const data = dataArray.shift();
    console.log(data);
  }
}
