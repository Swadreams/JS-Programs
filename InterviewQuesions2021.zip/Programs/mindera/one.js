console.log('Count 1 : ', count);

var count = 100;

console.log('Count 2: ', count);

function getCount() {
  console.log('Count 3 :', count);
  var count = 200;
  console.log('Count 4', count);
}

console.log('Count 5: ', count);

getCount();

console.log('Count 6: ', count);
