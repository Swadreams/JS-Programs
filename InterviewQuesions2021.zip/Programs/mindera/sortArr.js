const inputArr = [4, 2, 'swap', 5, -5];

function sortArr(arr) {
  if (!arr.length) {
    return 'Array should not be blank';
  } else if (arr.length === 1) {
    return arr;
  } else {
    for (let i = 0; i < arr.length; i++) {
      for (let j = 0; j < arr.length - i; j++) {
        if (isNaN(arr[j])) {
          const el = arr.splice(j, 1);
          arr.push(el);
        } else if (isNaN(arr[j])) {
          const el = arr.splice(j + 1, 1);
          arr.push(el);
        }

        if (arr[j] >= arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        }
      }
    }
    return arr;
  }
}

console.log(sortArr(inputArr));
document.write(sortArr(inputArr));
