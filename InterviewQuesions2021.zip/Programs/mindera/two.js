var person1 = {
  name: 'Rahul',
  getName() {
    return this.name;
  },
};

var person2 = {
  name: 'Swapnil',
};

console.log(person1.getName.call(person2));
