function dateVersion(date) {
  const inputDate = date.setHours(0, 0, 0, 0);
  const today = new Date().setHours(0, 0, 0, 0);
  var age = new Date(today).getFullYear() - new Date(inputDate).getFullYear();
  console.log('Age is: ', age);
  if (inputDate < today) {
    return 'Older Date';
  } else if (inputDate == today) {
    return 'Todays date';
  } else {
    return 'Future date';
  }
}

var past = new Date('1990-05-20');
var future = new Date('2030-10-10');

console.log(dateVersion(past));
