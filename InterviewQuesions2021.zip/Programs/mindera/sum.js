function sum() {
  var i,
    l,
    result = 0;
  console.log(arguments[0].length);
  for (i = 0, l = arguments[0].length; i < l; i++) {
    result += arguments[i];
  }
  return result;
}

console.log(sum([1, 3, 3]));
