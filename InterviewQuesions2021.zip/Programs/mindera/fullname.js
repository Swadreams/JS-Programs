function fullName(firstName) {
  var nameIntro = 'Full Name is ';
  function lastName(theLastName) {
    return nameIntro + firstName + ' ' + theLastName;
  }

  return lastName;
}

var fName = fullName('John');
console.log(fName('Doe'));
