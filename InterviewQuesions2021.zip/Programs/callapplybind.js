let add = function (c, d) {
  console.log(this.a + this.b + c + d);
};

let obj = {
  a: 1,
  b: 2,
};

add.call(obj, 3, 4);

let argsToArray = function () {
  //console.log(arguments);
  console.log([].slice.call(arguments));
};

argsToArray(1, 2, 3);

let mammal = function (legs) {
  this.legs = legs;
};

let cat = function (legs, isDomisticated) {
  mammal.call(this, legs);
  this.isDomisticated = isDomisticated;
};

let lion = new cat(4, false);
console.log(lion);

let numArray = [1, 2, 3];

console.log(Math.min.apply(null, numArray));

let button = function (content) {
  this.content = content;
};

button.prototype.click = function () {
  console.log(`${this.content} clicked`);
};

let newButton = new button('add');

let looseClick = newButton.click.bind(newButton);

looseClick();

let myObj = {
  asyncGet(cb) {
    cb();
  },
  parse() {
    console.log('parse called');
  },
  render() {
    this.asyncGet(
      function () {
        this.parse();
      }.bind(this)
    );
  },
};

myObj.render();
