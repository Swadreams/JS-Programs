describe('calculator.js', function() { // collection of specs //suite
    it('should add number to a total', () => {
        //AAA Arrange, Act, Assert
        const calculator = new Calculator(); // Arrange

        calculator.add(5); //Act

        expect(calculator.total).toBe(5); //Assert
        expect(calculator.total).not.toBe('a');
        // toBe Matcher
    }); // spec / test

    it('should subtract number to total', () => {
        const calculator = new Calculator();
        const calculator2 = new Calculator();
        // calculator.total = null;
        // calculator.subtract(5);
        // expect(calculator.total).toBe(5);
        expect(calculator).toEqual(calculator2);
        expect(calculator).toBeTruthy();
        expect(calculator).not.toBeFalsy();
        expect(calculator.add).toBeDefined();
        expect(calculator.subtract).not.toBeUndefined();
    });
    it('should be null', () => {
        const calculator = new Calculator();
        const calculator2 = new Calculator();
        calculator.total = null;
        expect(calculator.total).toBeNull();
    });

    it('should contain constructor sub string', () => {
        const calculator = new Calculator();
        expect(calculator.constructor.name).toContain('Calc');
    });

    it('should not be a NaN', () => {
        const calculator = new Calculator();
        calculator.total = 2;
        calculator.multiple('a');
        expect(calculator.total).toBeNaN();
    });

    it('should throw an error', () => {
        const calculator = new Calculator();
        calculator.total = 200;
        expect(function() { calculator.divide(0) }).toThrow();
        expect(function() { calculator.divide(0) }).toThrowError(Error, 'Cannot divide by zero.');
    });

    it('should match the expression', () => {
        const calculator = new Calculator();
        calculator.total = 200;
        expect(calculator.add(10)).toBe(210);
        expect(calculator.total).toMatch(/-?\d+/);
        expect(typeof calculator.total).toMatch('number');
    });
});