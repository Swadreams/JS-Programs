describe('calculator', () => {
    let calculator;
    let abc;
    //Setup 
    //teardown
    beforeEach(()=> {
        //Setup
        calculator = new Calculator();
        jasmine.addMatchers(customMatchers);
    });
    beforeAll(() => {
        abc = 123;
    });
    afterEach(() => {
        //teardown
        calculator = null;
    });
    afterAll(() => {
        abc = null;
    });


    it('should add numbers to total', () => {
        calculator.add(5);
        expect(calculator.total).toBe(5);
    });

    it('should subtract numbers to total', () => {
        calculator.total = 10;
        calculator.subtract(5);
        expect(calculator.total).toBe(5);
    });

    it('should multiply number by total', () => {

        calculator.total = 100;
        calculator.multiple(2);
        expect(calculator.total).toBe(200);
    });

    it('should divide number by total', () => {

        calculator.total = 200;
        calculator.divide(2);
        expect(calculator.total).toBe(100);
    });

    it('should has constructor', () => {
        const calculator2 = new Calculator();
        expect(calculator).toEqual(calculator2);
    });

    it('can be instantiated', () => {
        const calculator2 = new Calculator();
        expect(calculator).toBeTruthy();
        expect(calculator2).toBeTruthy();
    });

    it('instantiates unique object', () => {
        const calculator2 = new Calculator();
        expect(calculator).not.toBe(calculator2);
    });

    it('has to be instance of Calculator', () => {
        //positive matchers
        //negative matchers
        expect(calculator).toBeCalculator();
        expect(1).not.toBeCalculator();
    });
});