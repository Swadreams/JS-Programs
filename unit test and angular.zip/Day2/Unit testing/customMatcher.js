const customMatchers = {
    toBeCalculator: () => {
        return {
            compare: (actual) => {
                const result = {
                    pass: actual instanceof Calculator,
                    message: ''
                };

                if(result.pass) {
                    result.message = `Exceptation ${actual} not to be an instance of Calculator`;
                } else {
                    result.message = `Exceptation ${actual} to be an instance of Calculator`;
                }

                return result;
            }
        }
    },
    //toBeMobiquity: () => {}
}