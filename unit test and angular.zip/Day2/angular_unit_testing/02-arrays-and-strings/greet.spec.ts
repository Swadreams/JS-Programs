import { greet } from './greet';

describe('Greet', () => {
    it('should include name in a message', () => {
        const text = 'Mobiquity';
        expect(greet(text)).toContain(text);
    });
})