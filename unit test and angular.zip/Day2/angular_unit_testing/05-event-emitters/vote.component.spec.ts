import { VoteComponent } from './vote.component';
describe('VoteComponent', () => {
  let component: VoteComponent;
  beforeEach(()=>{
    component = new VoteComponent();
  });
  it('should raise an voteChange event when upvoted', () => {
    let totalVote = null;
    component.voteChanged.subscribe(tv => totalVote = tv);
    component.upVote();
    expect(totalVote).toBe(1);
  });
});