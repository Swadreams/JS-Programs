describe('VoterComponent', () => {

  beforeEach(() => {
  });

  it('', () => {});
});
