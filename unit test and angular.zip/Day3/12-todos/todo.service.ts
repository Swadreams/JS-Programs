import { Injectable } from '@angular/core'; 
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
type Todo = {

}
@Injectable()
export class TodoService { 
  constructor(private http: HttpClient) { 
  }

  add(todo) {
    return this.http.post('...', todo);
  }

  getTodos(): Observable<Todo[]> { 
    return this.http.get<Todo[]>('...');
  }

  getTodosPromise() {
    return this.http.get('...');
  }

  delete(id) {
    return this.http.delete('...');
  }
}